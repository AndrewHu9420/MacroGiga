#ifndef _INIT_H_
#define _INIT_H_

extern void Delay_ms(uint16_t delayCnt);

extern void Delay_us(uint16_t delayCnt);

extern void Init_System(void);


#endif
